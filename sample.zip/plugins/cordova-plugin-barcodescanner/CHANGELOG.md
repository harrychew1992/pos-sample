<a name="0.7.4"></a>
## [0.7.4](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/v0.7.3...v0.7.4) (2018-02-01)



<a name="0.7.3"></a>
## [0.7.3](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/v0.7.2...v0.7.3) (2017-09-28)


### Bug Fixes

* **xml-error:** Use newer plugin helper xml ([38d16c1](https://github.com/hypery2k/cordova-barcodescanner-plugin/commit/38d16c1)), closes [#27](https://github.com/hypery2k/cordova-barcodescanner-plugin/issues/27)



<a name="0.7.2"></a>
## [0.7.2](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/v0.7.1...v0.7.2) (2017-08-23)


### Bug Fixes

* **permission-error:** Corrected permissions ([287115d](https://github.com/hypery2k/cordova-barcodescanner-plugin/commit/287115d)), closes [#12](https://github.com/hypery2k/cordova-barcodescanner-plugin/issues/12)



<a name="0.7.1"></a>
## [0.7.1](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/v0.7.0...v0.7.1) (2017-07-14)


### Bug Fixes

* **permission-error:** Corrected permissions ([1a498f6](https://github.com/hypery2k/cordova-barcodescanner-plugin/commit/1a498f6)), closes [#12](https://github.com/hypery2k/cordova-barcodescanner-plugin/issues/12) [#19](https://github.com/hypery2k/cordova-barcodescanner-plugin/issues/19)



<a name="0.7.0"></a>
# [0.7.0](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/v0.5.0...v0.7.0) (2015-04-25)



<a name="0.5.0"></a>
# [0.5.0](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/1.2.0...v0.5.0) (2015-03-01)



<a name="1.2.0"></a>
# [1.2.0](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/1.1.0...1.2.0) (2014-07-25)



<a name="1.1.0"></a>
# [1.1.0](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/1.0.2...1.1.0) (2013-10-23)



<a name="1.0.2"></a>
## [1.0.2](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/1.0.1...1.0.2) (2013-09-27)



<a name="1.0.1"></a>
## [1.0.1](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/1.0.0...1.0.1) (2013-09-26)



<a name="1.0.0"></a>
# [1.0.0](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.7.2...1.0.0) (2013-09-12)



<a name="0.7.2"></a>
## [0.7.2](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.7.1...0.7.2) (2013-09-11)



<a name="0.7.1"></a>
## [0.7.1](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.7.0...0.7.1) (2013-09-10)



<a name="0.7.0"></a>
# [0.7.0](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.6.0...0.7.0) (2013-08-15)



<a name="0.6.0"></a>
# [0.6.0](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.5.5...0.6.0) (2013-07-17)



<a name="0.5.5"></a>
## [0.5.5](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.5.4...0.5.5) (2013-07-09)



<a name="0.5.4"></a>
## [0.5.4](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.5.3...0.5.4) (2013-07-04)



<a name="0.5.3"></a>
## [0.5.3](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.5.2...0.5.3) (2013-06-15)



<a name="0.5.2"></a>
## [0.5.2](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.5.0...0.5.2) (2013-06-10)



<a name="0.5.0"></a>
# [0.5.0](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.4.0...0.5.0) (2013-05-30)



<a name="0.4.0"></a>
# [0.4.0](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.3.1...0.4.0) (2013-04-24)



<a name="0.3.1"></a>
## [0.3.1](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.3.0...0.3.1) (2013-03-28)



<a name="0.3.0"></a>
# [0.3.0](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.2.2...0.3.0) (2013-02-01)



<a name="0.2.2"></a>
## [0.2.2](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.2.1...0.2.2) (2012-12-18)



<a name="0.2.1"></a>
## [0.2.1](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.2.0...0.2.1) (2012-12-12)



<a name="0.2.0"></a>
# [0.2.0](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.1.2...0.2.0) (2012-11-09)



<a name="0.1.2"></a>
## [0.1.2](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.1.1...0.1.2) (2012-11-08)



<a name="0.1.1"></a>
## [0.1.1](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.1.0...0.1.1) (2012-10-29)



<a name="0.1.0"></a>
# [0.1.0](https://github.com/hypery2k/cordova-barcodescanner-plugin/compare/0.0.1...0.1.0) (2012-10-18)



<a name="0.0.1"></a>
## 0.0.1 (2012-10-16)



